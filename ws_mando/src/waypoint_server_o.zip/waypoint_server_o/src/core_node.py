#!/usr/bin/env python3
import rospy
from custom_msg_pkg.msg import WaypointArray  # 사용자 지정 메시지를 임포트합니다.
from std_msgs.msg import Int32  # std_msgs.msg 모듈에서 Int32 메시지를 가져옵니다.


class WaypointProcessor(object):

    def __init__(self):
        rospy.init_node('waypoint_processor_node', anonymous=True)
        self.waypoint_sub = rospy.Subscriber('waypoint_utm', WaypointArray, self.callback)
        
        # Publisher for the custom control message
        self.control_pub = rospy.Publisher('custom_control', Int32, queue_size=10)

        # Subscriber for get link addresses
        self.link_sub = rospy.Subscriber('current_link', Int32, self.link_callback)

    def link_callback(self, link_msg):
        link = link_msg.data
        control_command = ""

        if link == 1:
            control_command = "carcontrol_on"
            print("111")
        elif link == 2:
            control_command = "creep_carcontrol_on"
            print("222")
        elif link == 3:
            control_command = "carcontrol_on"
            print("333")
        elif link == 4:
            control_command = "creep_carcontrol_on"
            print("444")
        elif link == 5:
            control_command = "ssp_on"
        elif link == 6:
            control_command = "carcontrol_on"
        elif link == 7:
            control_command = "creep_carcontrol_on"
        elif link == 8:
            control_command = "carcontrol_on"

        # Create a custom control message and publish it
        control_msg = Int32()
        control_msg.msg = link
        # control_msg.control_command = control_command

        self.control_pub.publish(control_msg)
        print(link)

    def callback(self, waypoint_msg):
        # Handle waypoint data if needed
        pass

if __name__ == "__main__":
    try:
        waypoint_processor = WaypointProcessor()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
